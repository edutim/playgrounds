import SwiftUI

struct ShapeView: View {
    @EnvironmentObject private var vm: ViewModel
    
    var body: some View {
        HStack(spacing: 40) {
            Text("Shape View Here!")
            /*
            Rectangle()
                .strokeBorder(Color.black, lineWidth: 4)
                .background(Color.blue)
                .frame(width: 50, height: 50)
                .onTapGesture {
                    vm.selectedShape = .square
                }
                .scaleEffect(vm.selectedShape == .square ? 1.5 : 1.0)
            */
        }
    }
}

#Preview {
    ShapeView()
}


