import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Perimeter")
                .font(.largeTitle)
            Image(systemName: "ruler")
                .resizable()
                .frame(width: 100, height: 50)
            Spacer()
            Text("Tap a shape to determine the perimeter.")
                .font(.title)
            Spacer()
            ShapeView()
            Spacer()
            MathView()
            Spacer()
        }
        
    }
}
