import SwiftUI

struct ShapeView: View {
    @EnvironmentObject private var vm: ViewModel
    
    var body: some View {
        HStack(spacing: 40) {
            Rectangle()
                .strokeBorder(Color.black, lineWidth: 4)
                .background(Color.blue)
                .frame(width: 50, height: 50)
                .onTapGesture {
                    vm.selectedShape = .square
                }
                .scaleEffect(vm.selectedShape == .square ? 1.5 : 1.0)
                
            Rectangle()
                .strokeBorder(Color.black, lineWidth: 4)
                .background(Color.red)
                .frame(width: 100, height: 50)
                .onTapGesture {
                    vm.selectedShape = .rectangle
                }
                .scaleEffect(vm.selectedShape == .rectangle ? 1.5 : 1.0)
            Triangle()
                .strokeBorder(Color.black, lineWidth: 4)
                .background(Triangle().fill(Color.yellow))
                .frame(width: 100, height: 50)
                .onTapGesture {
                    vm.selectedShape = .triangle
                }
                .scaleEffect(vm.selectedShape == .triangle ? 1.5 : 1.0)
        }
    }
}

#Preview {
    ShapeView()
}


