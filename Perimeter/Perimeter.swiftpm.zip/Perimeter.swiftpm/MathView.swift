import SwiftUI
import Combine

struct MathView: View {
    @EnvironmentObject private var vm: ViewModel
    
    @State private var squareSideInput = ""
    @State private var squareAnswered = false
    
    @State private var rectangleSideInput1 = ""
    @State private var rectangleSideInput2 = ""
    @State private var rectangleAnswered = false
    
    @State private var triangleSideInput1 = ""
    @State private var triangleSideInput2 = ""
    @State private var triangleSideInput3 = ""
    @State private var triangleAnswered = false
    
    var body: some View {
        if vm.selectedShape == .none {
            Text("Please select a shape")
        }
        if vm.selectedShape == .square {
            if squareAnswered {
                VStack {
                    Text("Perimeter of a square =")
                        .padding()
                    Text("side + side + side + side")
                    HStack {
                        Text("Length of side")
                        Text(squareSideInput)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                    }
                    .padding()
                    HStack {
                        Text(squareSideInput)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(squareSideInput)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(squareSideInput)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(squareSideInput)
                            .padding()
                            .border(.green, width: 2)
                        Text("=")
                        Text(calculateSquare())
                            .padding()
                            .border(.green, width: 2)
                    }
                    .padding()
                    .foregroundColor(.green)
                    Button("Clear") {
                        squareSideInput = ""
                        squareAnswered = false
                    }
                    .buttonStyle(.borderedProminent)
                }
                .font(.system(size: 24))
            } else {
                VStack {
                    Text("You chose a square. Each side is the same, so enter the length of one side in the field below.")
                        .font(.system(size: 24))
                    HStack {
                        Text("Length of side")
                            .font(.system(size: 24))
                        TextField("", text: $squareSideInput)
                            .keyboardType(.numberPad)
                            .onReceive(Just(squareSideInput)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.squareSideInput = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Button("Submit") {
                            if !squareSideInput.isEmpty {
                                squareAnswered = true
                            }
                            
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
        }
        
        if vm.selectedShape == .rectangle {
            if rectangleAnswered {
                VStack {
                    Text("Perimeter of a rectangle =")
                        .padding()
                    Text("side 1 + side 1 + side 2 + side 2")
                    HStack {
                        Text("Length of side 1")
                        Text(rectangleSideInput1)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                        Text("Length of side 2")
                        Text(rectangleSideInput2)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                    }
                    .padding()
                    HStack {
                        Text(rectangleSideInput1)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(rectangleSideInput1)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(rectangleSideInput2)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(rectangleSideInput2)
                            .padding()
                            .border(.green, width: 2)
                        Text("=")
                        Text(calculateRectangle())
                            .padding()
                            .border(.green, width: 2)
                    }
                    .padding()
                    .foregroundColor(.green)
                    Button("Clear") {
                        rectangleSideInput1 = ""
                        rectangleSideInput2 = ""
                        rectangleAnswered = false
                    }
                    .buttonStyle(.borderedProminent)
                }
                .font(.system(size: 24))
            } else {
                VStack {
                    Text("You chose a rectangle. It has matching pairs of sides, so enter the length of side 1 and side 2 in the fields below.")
                        .font(.system(size: 24))
                    HStack {
                        Text("Length of side 1")
                            .font(.system(size: 24))
                        TextField("", text: $rectangleSideInput1)
                            .keyboardType(.numberPad)
                            .onReceive(Just(rectangleSideInput1)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.rectangleSideInput1 = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Text("Length of side 2")
                            .font(.system(size: 24))
                        TextField("", text: $rectangleSideInput2)
                            .keyboardType(.numberPad)
                            .onReceive(Just(rectangleSideInput2)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.rectangleSideInput2 = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Button("Submit") {
                            if !rectangleSideInput1.isEmpty && !rectangleSideInput2.isEmpty {
                                rectangleAnswered = true
                            }
                            
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
        }
        if vm.selectedShape == .triangle {
            if triangleAnswered {
                VStack {
                    Text("Perimeter of a triangle =")
                        .padding()
                    Text("side 1 + side 3 + side 3")
                    HStack {
                        Text("Length of side 1")
                        Text(triangleSideInput1)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                        Text("Length of side 2")
                        Text(triangleSideInput2)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                        Text("Length of side 3")
                        Text(triangleSideInput3)
                            .font(.title)
                            .padding()
                            .border(.blue, width: 2)
                    }
                    .padding()
                    HStack {
                        Text(triangleSideInput1)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(triangleSideInput2)
                            .padding()
                            .border(.green, width: 2)
                        Text("+")
                        Text(triangleSideInput3)
                            .padding()
                            .border(.green, width: 2)
                        Text("=")
                        Text(String(Int(triangleSideInput1)! + Int(triangleSideInput2)! + Int(triangleSideInput3)!))
                            .padding()
                            .border(.green, width: 2)
                    }
                    .padding()
                    .foregroundColor(.green)
                    Button("Clear") {
                        triangleSideInput1 = ""
                        triangleSideInput2 = ""
                        triangleSideInput3 = ""
                        triangleAnswered = false
                    }
                    .buttonStyle(.borderedProminent)
                }
                .font(.system(size: 24))
            } else {
                VStack {
                    Text("You chose a triangle. It has three sides, so enter the length of side 1, side 2, and side 3 in the fields below.")
                        .font(.system(size: 24))
                    HStack {
                        Text("Length of side 1")
                            .font(.system(size: 24))
                        TextField("", text: $triangleSideInput1)
                            .keyboardType(.numberPad)
                            .onReceive(Just(triangleSideInput1)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.triangleSideInput1 = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Text("Length of side 2")
                            .font(.system(size: 24))
                        TextField("", text: $triangleSideInput2)
                            .keyboardType(.numberPad)
                            .onReceive(Just(triangleSideInput2)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.triangleSideInput2 = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Text("Length of side 3")
                            .font(.system(size: 24))
                        TextField("", text: $triangleSideInput3)
                            .keyboardType(.numberPad)
                            .onReceive(Just(triangleSideInput3)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue {
                                    self.triangleSideInput3 = filtered
                                }
                            }
                            .textFieldStyle(.roundedBorder)
                            .font(.title)
                            .frame(width: 100)
                        Button("Submit") {
                            if !triangleSideInput1.isEmpty && !triangleSideInput2.isEmpty && !triangleSideInput3.isEmpty {
                                triangleAnswered = true
                            }
                            
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
            }
        }
        
    }
    
    func calculateSquare() -> String {
        let sideOne = Int(squareSideInput)!
        let result = sideOne + sideOne + sideOne + sideOne
        return String(result)
        
    }
    
    func calculateRectangle() -> String {
        let sideOne = Int(rectangleSideInput1)!
        let sideTwo = Int(rectangleSideInput2)!
        let result = sideOne + sideOne + sideTwo + sideTwo
        return String(result)
    }
    
    func calculateTriangle() -> String {
        let sideOne = Int(triangleSideInput1)!
        let sideTwo = Int(triangleSideInput2)!
        let sideThree = Int(triangleSideInput3)!
        let result = sideOne + sideTwo + sideThree
        return String(result)
    }
    
}

#Preview {
    MathView()
}
